import express from "express";
import { protect, adminOnly } from "../middleware/authMiddleware.js";
import {
  placeOrder,
  getMyOrders,
  getAllOrders,
  updateOrderStatus
} from "../controllers/orderController.js";

const router = express.Router();

// ✅ Protected: Only logged-in user can place/fetch orders
router.post("/", protect, placeOrder);
router.get("/my-orders", protect, getMyOrders);

// ✅ Admin: Get all + Manage
router.get("/", protect, adminOnly, getAllOrders);
router.put("/:id", protect, adminOnly, updateOrderStatus);

export default router;
