// backend/routes/adminRoutes.js

import express from "express";
import {
  getAllUsers,
  updateUserRole,
  getPendingProducts,
  handleProductApproval,
  getAccessRequests,
  handleAccessRequest,
  getOrderStats,
  getAllOrders
} from "../controllers/adminController.js"; // ✅ FIXED PATH
import { verifyAdmin } from "../middleware/verifyAdmin.js";

const router = express.Router();

// ✅ User management
router.get("/users", verifyAdmin, getAllUsers);
router.put("/users/:id/role", verifyAdmin, updateUserRole);

// ✅ Product approval
router.get("/products/pending", verifyAdmin, getPendingProducts);
router.put("/products/:id/approve", verifyAdmin, handleProductApproval);

// ✅ Access requests
router.get("/access-requests", verifyAdmin, getAccessRequests);
router.put("/access-requests/:id/handle", verifyAdmin, handleAccessRequest);

// ✅ Orders & stats
router.get("/orders", verifyAdmin, getAllOrders);
router.get("/stats", verifyAdmin, getOrderStats);

export default router;
