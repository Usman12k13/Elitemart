import express from "express";
import multer from "multer";
import streamifier from "streamifier";
import cloudinary from "../config/cloudinary.js";
import Product from "../models/Product.js";

const router = express.Router();

// Use memory storage since we stream to Cloudinary
const upload = multer({ storage: multer.memoryStorage() });

/* --------------------------- CREATE PRODUCT --------------------------- */
router.post("/", upload.single("image"), async (req, res) => {
  try {
    const { title, description, price, category } = req.body;

    // ✅ Check all required fields
    if (!title || !price || !category || !req.file) {
      return res.status(400).json({
        success: false,
        message: "All fields (title, price, category, image) are required.",
      });
    }

    // ✅ Upload to Cloudinary
    const uploadStream = cloudinary.uploader.upload_stream(
      { folder: `products/${category}` },
      async (error, result) => {
        if (error) {
          console.error("Cloudinary upload failed:", error);
          return res
            .status(500)
            .json({ success: false, message: "Image upload failed" });
        }

        // ✅ Create product in MongoDB
        const newProduct = await Product.create({
          title,
          description,
          price,
          category,
          imageUrl: result.secure_url,
          cloudinary_id: result.public_id,
        });

        res.status(201).json({
          success: true,
          message: "Product created successfully",
          product: newProduct,
        });
      }
    );

    streamifier.createReadStream(req.file.buffer).pipe(uploadStream);
  } catch (err) {
    console.error("Create product error:", err);
    res.status(500).json({ success: false, message: "Server error" });
  }
});

/* ----------------------- GET ALL OR FILTER BY CATEGORY ----------------------- */
router.get("/", async (req, res) => {
  try {
    const { category } = req.query;
    const filter = category ? { category } : {};
    const products = await Product.find(filter).sort({ createdAt: -1 });
    res.json({ success: true, count: products.length, products });
  } catch (err) {
    console.error("Fetch products error:", err);
    res.status(500).json({ success: false, message: "Server error" });
  }
});

/* ------------------------------ GET SINGLE PRODUCT ------------------------------ */
router.get("/:id", async (req, res) => {
  try {
    const product = await Product.findById(req.params.id);
    if (!product)
      return res.status(404).json({ success: false, message: "Product not found" });

    res.json({ success: true, product });
  } catch (err) {
    console.error("Get product error:", err);
    res.status(500).json({ success: false, message: "Server error" });
  }
});

/* ------------------------------ UPDATE PRODUCT ------------------------------ */
router.put("/:id", upload.single("image"), async (req, res) => {
  try {
    const product = await Product.findById(req.params.id);
    if (!product)
      return res.status(404).json({ success: false, message: "Product not found" });

    const { title, description, price, category } = req.body;

    // ✅ If new image uploaded, delete old one and re-upload
    if (req.file) {
      if (product.cloudinary_id)
        await cloudinary.uploader.destroy(product.cloudinary_id);

      const uploadStream = cloudinary.uploader.upload_stream(
        { folder: `products/${category || product.category}` },
        async (error, result) => {
          if (error) {
            console.error("Cloudinary update failed:", error);
            return res
              .status(500)
              .json({ success: false, message: "Image upload failed" });
          }

          product.title = title || product.title;
          product.description = description || product.description;
          product.price = price || product.price;
          product.category = category || product.category;
          product.imageUrl = result.secure_url;
          product.cloudinary_id = result.public_id;

          await product.save();
          res.json({
            success: true,
            message: "Product updated successfully",
            product,
          });
        }
      );

      streamifier.createReadStream(req.file.buffer).pipe(uploadStream);
    } else {
      // ✅ Update only text fields
      product.title = title || product.title;
      product.description = description || product.description;
      product.price = price || product.price;
      product.category = category || product.category;

      await product.save();
      res.json({
        success: true,
        message: "Product updated successfully",
        product,
      });
    }
  } catch (err) {
    console.error("Update product error:", err);
    res.status(500).json({ success: false, message: "Server error" });
  }
});

/* ------------------------------ DELETE PRODUCT ------------------------------ */
router.delete("/:id", async (req, res) => {
  try {
    const product = await Product.findById(req.params.id);
    if (!product)
      return res.status(404).json({ success: false, message: "Product not found" });

    // ✅ Delete image from Cloudinary
    if (product.cloudinary_id)
      await cloudinary.uploader.destroy(product.cloudinary_id);

    await product.deleteOne();

    res.json({
      success: true,
      message: "Product deleted successfully",
    });
  } catch (err) {
    console.error("Delete product error:", err);
    res.status(500).json({ success: false, message: "Server error" });
  }
});

export default router;
