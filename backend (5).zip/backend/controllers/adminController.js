import User from "../models/User.js";
import Product from "../models/Product.js";
import Order from "../models/Order.js";
import AccessRequest from "../models/AccessRequest.js";

/* ---------------- USERS ---------------- */
export const getAllUsers = async (req, res) => {
  try {
    const users = await User.find({}, "-password");
    res.json({ users });
  } catch (err) {
    res.status(500).json({ message: "Error fetching users" });
  }
};

export const updateUserRole = async (req, res) => {
  try {
    const { id } = req.params;
    const { role } = req.body;

    const user = await User.findByIdAndUpdate(id, { role }, { new: true });
    if (!user) return res.status(404).json({ message: "User not found" });

    res.json({ message: "User role updated", user });
  } catch {
    res.status(500).json({ message: "Error updating role" });
  }
};

/* ---------------- PRODUCTS ---------------- */
export const getPendingProducts = async (req, res) => {
  try {
    const products = await Product.find({ status: "pending" });
    res.json({ products });
  } catch {
    res.status(500).json({ message: "Error fetching pending products" });
  }
};

export const handleProductApproval = async (req, res) => {
  try {
    const { id } = req.params;
    const { action } = req.body;
    const status = action === "approve" ? "approved" : "rejected";

    const product = await Product.findByIdAndUpdate(id, { status }, { new: true });
    if (!product) return res.status(404).json({ message: "Product not found" });

    res.json({ message: `Product ${status}`, product });
  } catch {
    res.status(500).json({ message: "Error updating product status" });
  }
};

/* ---------------- ACCESS REQUESTS ---------------- */
export const getAccessRequests = async (req, res) => {
  try {
    const requests = await AccessRequest.find({ status: "pending" });
    res.json({ requests });
  } catch {
    res.status(500).json({ message: "Error fetching access requests" });
  }
};

export const handleAccessRequest = async (req, res) => {
  try {
    const { id } = req.params;
    const { approve } = req.body;

    const status = approve ? "approved" : "rejected";
    const request = await AccessRequest.findByIdAndUpdate(id, { status }, { new: true });

    if (!request) return res.status(404).json({ message: "Request not found" });

    res.json({ message: `Access request ${status}`, request });
  } catch {
    res.status(500).json({ message: "Error handling access request" });
  }
};

/* ---------------- ORDERS & ANALYTICS ---------------- */
export const getAllOrders = async (req, res) => {
  try {
    const orders = await Order.find().populate("userId", "fullName email");
    res.json({ orders });
  } catch {
    res.status(500).json({ message: "Error fetching orders" });
  }
};

export const getOrderStats = async (req, res) => {
  try {
    const totalUsers = await User.countDocuments();
    const totalProducts = await Product.countDocuments();
    const totalOrders = await Order.countDocuments();
    const totalSales = await Order.aggregate([
      { $group: { _id: null, total: { $sum: "$totalPrice" } } },
    ]);

    res.json({
      totalUsers,
      totalProducts,
      totalOrders,
      totalSales: totalSales[0]?.total || 0,
    });
  } catch {
    res.status(500).json({ message: "Error fetching analytics" });
  }
};
