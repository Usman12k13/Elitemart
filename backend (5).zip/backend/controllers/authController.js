// backend/controllers/authController.js
import asyncHandler from "express-async-handler";
import jwt from "jsonwebtoken";
import User from "../models/User.js";

const createAccessToken = (user) =>
  jwt.sign({ id: user._id, role: user.role }, process.env.JWT_SECRET, {
    expiresIn: process.env.JWT_EXPIRES || "15m",
  });

const createRefreshToken = (user) =>
  jwt.sign({ id: user._id }, process.env.JWT_REFRESH_SECRET, {
    expiresIn: process.env.JWT_REFRESH_EXPIRES || "7d",
  });

const cookieOptions = {
  httpOnly: true,
  secure: process.env.NODE_ENV === "production",
  sameSite: "lax",
};

// ✅ REGISTER — hash for users, not for admin
export const register = asyncHandler(async (req, res) => {
  const { fullName, email, password, role } = req.body;
  if (!fullName || !email || !password)
    return res.status(400).json({ message: "All fields are required" });

  const exists = await User.findOne({ email });
  if (exists)
    return res.status(409).json({ message: "Email already in use" });

  // If role is "admin", store password as plain text
  let user;
  if (role === "admin") {
    user = new User({
      fullName,
      email,
      password, // 👈 plain password for admin
      role: "admin",
    });
    // Skip password hashing for admin
    user.save({ validateBeforeSave: false });
  } else {
    user = await User.create({ fullName, email, password, role: "user" });
  }

  res.status(201).json({
    message: "Account created successfully",
    user: {
      id: user._id,
      fullName: user.fullName,
      email: user.email,
      role: user.role,
    },
  });
});

// ✅ LOGIN — plain password check for admin, hashed check for users
export const login = asyncHandler(async (req, res) => {
  const { email, password } = req.body;
  if (!email || !password)
    return res.status(400).json({ message: "Email and password required" });

  const user = await User.findOne({ email }).select("+password");
  if (!user) return res.status(401).json({ message: "Invalid credentials" });

  // If admin, check plain password
  if (user.role === "admin") {
    if (user.password !== password)
      return res.status(401).json({ message: "Invalid admin credentials" });
  } else {
    // Normal user -> compare hashed password
    const isMatch = await user.matchPassword(password);
    if (!isMatch)
      return res.status(401).json({ message: "Invalid user credentials" });
  }

  const accessToken = createAccessToken(user);
  const refreshToken = createRefreshToken(user);

  user.refreshTokens.push({ token: refreshToken, createdAt: new Date() });
  await user.save();

  // Set cookies
  res.cookie("refreshToken", refreshToken, {
    ...cookieOptions,
    maxAge: 7 * 24 * 60 * 60 * 1000, // 7 days
  });

  res.cookie("accessToken", accessToken, {
    ...cookieOptions,
    maxAge: 15 * 60 * 1000, // 15 minutes
  });

  res.json({
    accessToken,
    user: {
      id: user._id,
      fullName: user.fullName,
      email: user.email,
      role: user.role,
    },
    message: "Login successful",
  });
});

// ✅ REFRESH TOKEN
export const refreshToken = asyncHandler(async (req, res) => {
  const token = req.cookies?.refreshToken;
  if (!token) return res.status(401).json({ message: "No refresh token" });

  try {
    const payload = jwt.verify(token, process.env.JWT_REFRESH_SECRET);
    const user = await User.findById(payload.id);
    if (!user) return res.status(401).json({ message: "Invalid token user" });

    const found = user.refreshTokens.find((rt) => rt.token === token);
    if (!found) return res.status(401).json({ message: "Refresh token revoked" });

    const accessToken = createAccessToken(user);

    res.cookie("accessToken", accessToken, {
      ...cookieOptions,
      maxAge: 15 * 60 * 1000,
    });

    res.json({ accessToken });
  } catch (err) {
    res.status(401).json({ message: "Refresh token invalid" });
  }
});

// ✅ GET CURRENT USER
export const me = asyncHandler(async (req, res) => {
  const user = await User.findById(req.user.id).select("-password -refreshTokens");
  res.json({ user });
});

// ✅ LOGOUT
export const logout = asyncHandler(async (req, res) => {
  const token = req.cookies?.refreshToken;

  if (token) {
    try {
      const payload = jwt.verify(token, process.env.JWT_REFRESH_SECRET);
      const user = await User.findById(payload.id);

      if (user) {
        user.refreshTokens = user.refreshTokens.filter((rt) => rt.token !== token);
        await user.save();
      }
    } catch {}
  }

  res.clearCookie("refreshToken", cookieOptions);
  res.clearCookie("accessToken", cookieOptions);

  res.json({ message: "Logged out" });
});
