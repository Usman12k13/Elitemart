import asyncHandler from "express-async-handler";
import Order from "../models/Order.js";
import User from "../models/User.js";

/* ✅ Place Order */
export const placeOrder = asyncHandler(async (req, res) => {
  const { items, form, subtotal, delivery, discount, total } = req.body;

  if (!items?.length) return res.status(400).json({ message: "Cart is empty" });

  const user = await User.findById(req.user.id);
  if (!user) return res.status(401).json({ message: "User not found" });

  const order = await Order.create({
    user: {
      id: user._id,
      fullName: user.fullName,
      email: user.email
    },
    items,
    address: form,
    subtotal,
    delivery,
    discount,
    total
  });

  res.status(201).json({ success: true, message: "Order placed", order });
});

/* ✅ User Orders */
export const getMyOrders = asyncHandler(async (req, res) => {
  const orders = await Order.find({ "user.id": req.user.id }).sort({ createdAt: -1 });
  res.json({ success: true, orders });
});

/* ✅ Admin — Get All Orders */
export const getAllOrders = asyncHandler(async (req, res) => {
  const orders = await Order.find().sort({ createdAt: -1 });
  res.json({ success: true, count: orders.length, orders });
});

/* ✅ Admin — Update Order Status */
export const updateOrderStatus = asyncHandler(async (req, res) => {
  const { id } = req.params;
  const { status } = req.body;

  const order = await Order.findById(id);
  if (!order) return res.status(404).json({ message: "Order not found" });

  order.status = status;
  await order.save();

  res.json({ success: true, message: "Status updated", order });
});
