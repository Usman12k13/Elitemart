// backend/server.js
import express from "express";
import mongoose from "mongoose";
import cors from "cors";
import dotenv from "dotenv";
import cookieParser from "cookie-parser";
import helmet from "helmet";
import rateLimit from "express-rate-limit";
import bcrypt from "bcryptjs";
import path from "path";
import { fileURLToPath } from "url";

import authRoutes from "./routes/authRoutes.js";
import productRoutes from "./routes/productRoutes.js";
import { errorHandler } from "./middleware/errorhandler.js";
import orderRoutes from "./routes/orderRoutes.js";
import adminRoutes from "./routes/adminRoutes.js";
import User from "./models/User.js";

dotenv.config();
const app = express();

// ============================================
// ✅ 1. SECURITY & BASIC MIDDLEWARE
// ============================================
app.use(helmet());
app.use(express.json());
app.use(cookieParser());

// ✅ Rate Limiting
app.use(
  rateLimit({
    windowMs: 15 * 60 * 1000, // 15 minutes
    max: 200, // Limit each IP
  })
);

// ============================================
// ✅ 2. CORS CONFIGURATION
// ============================================
const allowedOrigins = [
  process.env.CLIENT_URL || "http://localhost:3000",
  process.env.VITE_DEV_URL || "http://localhost:5173",
  "https://www.elitemart.pk",
  "https://elitemart.pk",
];

app.use(
  cors({
    origin: (origin, callback) => {
      if (!origin) return callback(null, true); // Allow Postman/server
      if (allowedOrigins.includes(origin)) return callback(null, true);
      return callback(new Error("CORS not allowed"));
    },
    credentials: true,
  })
);

// ============================================
// ✅ 3. DATABASE CONNECTION + ADMIN SETUP
// ============================================
mongoose.set("strictQuery", false);
mongoose
  .connect(process.env.MONGODB_URI)
  .then(async () => {
    console.log("✅ MongoDB Connected Successfully");

    const adminEmail = "usmanjamil12k13@gmail.com";
    const adminPassword = "ElitemartAdmin1";

    try {
      const existingAdmin = await User.findOne({ email: adminEmail });
      if (!existingAdmin) {
        const hashed = await bcrypt.hash(adminPassword, 10);
        await User.create({
          fullName: "Admin User",
          email: adminEmail,
          password: hashed,
          role: "admin",
        });
        console.log("👑 Default Admin Account Created Successfully!");
      } else {
        console.log("👑 Admin Account Already Exists.");
      }
    } catch (err) {
      console.error("⚠️ Admin Account Setup Error:", err.message);
    }
  })
  .catch((err) => console.error("❌ MongoDB Connection Error:", err.message));

// ============================================
// ✅ 4. API ROUTES
// ============================================
app.use("/api/auth", authRoutes);
app.use("/api/products", productRoutes);
app.use("/api/orders", orderRoutes);
app.use("/api/admin", adminRoutes);

// ============================================
// ✅ 5. HEALTH CHECK
// ============================================
app.get("/health", (req, res) => res.send("✅ Backend server is healthy!"));

// ============================================
// ✅ 6. FRONTEND FALLBACK (Optional, if serving React from same server)
// ============================================

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

// If you deploy frontend separately on cPanel root, skip this section.
// But if you upload the built React files under `backend/client/dist`, then keep it:

const clientDistPath = path.join(__dirname, "client", "dist");
app.use(express.static(clientDistPath));

app.get("*", (req, res) => {
  // Ensure it doesn't override API routes
  if (req.path.startsWith("/api")) {
    return res.status(404).json({ message: "API route not found" });
  }
  res.sendFile(path.join(clientDistPath, "index.html"));
});

// ============================================
// ✅ 7. GLOBAL ERROR HANDLER
// ============================================
app.use(errorHandler);

// ============================================
// ✅ 8. SERVER START
// ============================================
const PORT = process.env.PORT || 5000;
app.listen(PORT, () =>
  console.log(`🚀 Server running in ${process.env.NODE_ENV} on port ${PORT}`)
);
