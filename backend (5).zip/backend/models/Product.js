// backend/models/Product.js
import mongoose from "mongoose";

const productSchema = new mongoose.Schema(
  {
    title: { type: String, required: true },
    description: { type: String, default: "" },
    price: { type: Number, required: true },
    category: { type: String, required: true },
    imageUrl: { type: String, required: true },
    cloudinary_id: { type: String },
    // New fields:
    status: { type: String, enum: ["Pending", "Approved", "Rejected"], default: "Approved" },
    submittedBy: {
      id: { type: mongoose.Schema.Types.ObjectId, ref: "User" },
      email: String,
      name: String
    },
    stocks: { type: Number, default: 0 }
  },
  { timestamps: true }
);

export default mongoose.model("Product", productSchema);
