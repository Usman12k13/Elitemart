import mongoose from "mongoose";

// ✅ Define item schema — unchanged
const orderItemSchema = new mongoose.Schema({
  productId: { type: mongoose.Schema.Types.ObjectId, ref: "Product", required: true },
  title: { type: String, required: true },
  imageUrl: { type: String },
  price: { type: Number, required: true },
  quantity: { type: Number, required: true, min: 1 },
});

// ✅ Define main order schema — kept intact but improved status enum
const orderSchema = new mongoose.Schema(
  {
    user: {
      id: { type: mongoose.Schema.Types.ObjectId, ref: "User", required: true },
      fullName: { type: String, required: true },
      email: { type: String, required: true },
    },

    items: [orderItemSchema],

    address: {
      contact: { type: String },
      altContact: { type: String },
      address: { type: String },
      country: { type: String },
      city: { type: String },
      postal: { type: String },
    },

    subtotal: { type: Number, required: true },
    delivery: { type: Number, default: 0 },
    discount: { type: Number, default: 0 },
    total: { type: Number, required: true },

    // ✅ Fixed enum: added "Out for Delivery" + "Delivered" + "Cancelled"
    status: {
      type: String,
      enum: [
        "Pending",
        "Approved",
        "Out for Delivery",
        "Delivered",
        "Rejected",
        "Cancelled",
      ],
      default: "Pending",
    },
  },
  { timestamps: true }
);

// ✅ Export model
export default mongoose.model("Order", orderSchema);
