// backend/models/User.js
import mongoose from "mongoose";
import bcrypt from "bcryptjs"; // more common & compatible

const userSchema = new mongoose.Schema(
  {
    fullName: { type: String, required: true, trim: true },
    email: { type: String, required: true, unique: true, lowercase: true, trim: true },
    password: { type: String, required: true, select: false }, // excluded by default
    role: { type: String, enum: ["user", "admin"], default: "user" },
    isVerified: { type: Boolean, default: true },
    refreshTokens: [
      {
        token: { type: String },
        createdAt: { type: Date, default: Date.now },
      }
    ]
  },
  { timestamps: true }
);

// ✅ Only hash password if newly added or updated
userSchema.pre("save", async function (next) {
  if (!this.isModified("password")) return next();
  if (!this.password) return next();
  const salt = await bcrypt.genSalt(10);
  this.password = await bcrypt.hash(this.password, salt);
  next();
});

// ✅ Matching password during login
userSchema.methods.matchPassword = async function (enteredPassword) {
  return await bcrypt.compare(enteredPassword, this.password);
};

export default mongoose.model("User", userSchema);
