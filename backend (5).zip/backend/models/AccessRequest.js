// backend/models/AccessRequest.js
import mongoose from "mongoose";

const accessRequestSchema = new mongoose.Schema(
  {
    fullName: {
      type: String,
      required: [true, "Full name is required"],
      trim: true,
    },
    email: {
      type: String,
      required: [true, "Email is required"],
      lowercase: true,
      trim: true,
    },
    status: {
      type: String,
      enum: ["pending", "approved", "rejected"],
      default: "pending",
    },
  },
  { timestamps: true }
);

const AccessRequest =
  mongoose.models.AccessRequest ||
  mongoose.model("AccessRequest", accessRequestSchema);

export default AccessRequest; // ✅ keep this exactly as is
